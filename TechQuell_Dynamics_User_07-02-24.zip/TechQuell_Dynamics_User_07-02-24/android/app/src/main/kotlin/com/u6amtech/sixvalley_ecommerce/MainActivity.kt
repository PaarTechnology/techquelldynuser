package com.pt.techquelldynamic

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
